# Hello Node App

This is a simple Node.js application that prints "Hello World" over HTTP.

## Run it

```bash
npm install
npm start
```
